# Cuework logo assets

This package contains the production-oriented vector and raster assets for the selected **Cue Mark** direction.

## Primary assets

- `svg/cuework-primary.svg` — Command Ink and Cue Orange horizontal lockup on a transparent background.
- `svg/cuework-reverse.svg` — white and Cue Orange horizontal lockup for dark backgrounds.
- `svg/cuework-one-color.svg` — single-color horizontal lockup.
- `svg/cuework-mark.svg` — two-color standalone Cue Mark.
- `svg/cuework-mark-one-color.svg` — single-color standalone Cue Mark.
- `svg/cuework-mark-reverse.svg` — standalone Cue Mark for dark backgrounds.
- `svg/cuework-wordmark.svg` — standalone wordmark matching the selected concept-board lettering.

## Raster assets

- `png/lockup/` — transparent primary and reverse lockups at 1x, 2x, and 4x.
- `png/app-icons/` — square app icons at 16, 32, 48, 180, 192, 512, and 1024 px.
- `favicon/` — favicon-ready 16 px and 32 px PNGs plus SVG.

## Color

- Command Ink: `#17231F`
- Working Paper: `#F5F2E9`
- Cue Orange: `#D9691D`
- White: `#FFFFFF`

## Typography

- Wordmark: drawn from Manrope Bold (700), matching the product type system (Visual & Verbal Identity Guide, Section 5), but the letterforms are outlined to vector paths in every SVG here -- not a live font reference. This is intentional: a logo must render identically everywhere, and a `font-family` reference silently falls back to whatever font (or lack of one) is installed on the viewing machine. Bold rather than Semibold is also intentional -- it's what balances against the mark's own stroke weight.
- If you ever need to re-edit the wordmark (not just recolor or rescale it), start from Manrope Bold again and re-outline -- don't hand-edit the path data.

## Usage rules

- Use the primary lockup on Working Paper, white, or another quiet light surface.
- Use the reverse lockup on Command Ink or a sufficiently dark photographic field.
- Use the one-color assets whenever the production method cannot preserve Cue Orange.
- Keep clear space around the lockup equal to at least the height of the wordmark's lowercase `u`.
- Do not recolor individual signal strokes, add shadows or gradients, or rotate the mark.
- At 16 px, use the favicon asset rather than scaling down the full lockup.
